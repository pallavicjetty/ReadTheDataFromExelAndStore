package utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.*;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExcelUtilis {
	
	public ExcelUtilis()
	{
		//this.driver=driver;
	}
	public void getRowCount()
	{
		String filePath = "C:\\Users\\Pallavi.C\\eclipse-workspace\\SeleniumAssignment\\TestData\\Data.xlsx";
        String sheetName = "Sheet1";

        try {
            readExcel(filePath, sheetName);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public static void readExcel(String filePath, String sheetName) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(filePath);

        try (Workbook workbook = WorkbookFactory.create(fileInputStream)) {
            Sheet sheet = workbook.getSheet(sheetName);

            if (sheet != null) {
                int rows = sheet.getPhysicalNumberOfRows();

                for (int rowIndex = 0; rowIndex < rows; rowIndex++) {
                    Row row = sheet.getRow(rowIndex);

                    if (row != null) {
                        int cells = row.getPhysicalNumberOfCells();

                        for (int cellIndex = 0; cellIndex < cells; cellIndex++) {
                            Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                            switch (cell.getCellType()) {
                                case STRING:
                                    System.out.print(cell.getStringCellValue());
                                    break;
                                case NUMERIC:
                                    System.out.print(cell.getNumericCellValue());
                                    break;
                                case BOOLEAN:
                                    System.out.print(cell.getBooleanCellValue());
                                    break;
                                case BLANK:
                                    System.out.print("Blank");
                                    break;
                                default:
                                    System.out.print("Unknown type");
                            }

                            System.out.print("\t");
                        }

                        System.out.println(); // Move to the next line after each row
                    }
                }
            }
        }
	}
	
	public void CreateNewSheet(List<WebElement>dropDownValue) {
        // Example usage
        String filePath = "C:\\Users\\Pallavi.C\\eclipse-workspace\\SeleniumAssignment\\TestData\\Data.xlsx";
        String newSheetName = "ActualValue";
        
        try {
            createAndWriteNewSheet(filePath, newSheetName, dropDownValue);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createAndWriteNewSheet(String filePath, String newSheetName, List<WebElement>dropDownValue) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(filePath);

        try (Workbook workbook = new XSSFWorkbook(fileInputStream)) {
        	int sheetIndex = workbook.getSheetIndex(newSheetName);
        	
        	if (sheetIndex != -1) {
                workbook.removeSheetAt(sheetIndex);
             }
        	
            // Create a new sheet
            Sheet newSheet = workbook.createSheet(newSheetName);

            // Remove all values from the new sheet (if it already exists)
            
            for(int i=0;i<dropDownValue.size();i++)
   		 	{
            	Row row = newSheet.createRow(i);
            	Cell cell = row.createCell(0);
                cell.setCellValue(dropDownValue.get(i).getText());
	   			 
	   			 //System.out.println(dropdownValue.get(i).getText());
   		 	}

            // Write the workbook with the new sheet to a file
            try (FileOutputStream fileOutputStream = new FileOutputStream(filePath)) {
                workbook.write(fileOutputStream);
                
            }
            catch(Exception e)
            {
            	System.out.println(e);
            	throw e;
            }

        }
    }
}
