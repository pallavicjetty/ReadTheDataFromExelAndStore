package SeleniumDemo.SeleniumAssignment.PageObjects;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.CommonMethod;
import utilities.ExcelUtilis;


public class HomePage extends CommonMethod {
	WebDriver driver;//coming from test class

	public HomePage(WebDriver driver){
		super(driver); //Call the constructor of parent class
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="txtStationFrom")
	private WebElement FromField;//driver.findElement(By.id(""));
	
	@FindBy(xpath="//*[@class='autocomplete']/div") 
	List<WebElement> dropdownValue;//driver.findelements(By.xpath(""));
	
	@FindBy(css="[title='Select Departure date for availability']")
	private WebElement SelectSortOnDate;
	
	@FindBy(xpath="(//td[@onclick])[31]")
	private WebElement Select30DaysFromTheCurrentDate;
	
	
	public void ClickFromField(String EnterKey)
	{
		FromField.click();
		FromField.clear();
		
		FromField.sendKeys(EnterKey);
	}
	
	public void SelectValueFromDropdown()
	{
		ExcelUtilis excelUtilis = new ExcelUtilis();
		excelUtilis.CreateNewSheet(dropdownValue);
		dropdownValue.get(3).click();
	}
	
	public void ReadDataFromDropdown()
	{
		 for(int i=0;i<dropdownValue.size();i++)
		 {
			 dropdownValue.get(i).getText();
			 System.out.println(dropdownValue.get(i).getText());
		 }
		 System.out.println("the End");
	}
	
	public void SelectSortOnDateFrom30Day()
	{
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
			
		}
		SelectSortOnDate.click();
		Select30DaysFromTheCurrentDate.click();
		System.out.println("the End");
	}
}
