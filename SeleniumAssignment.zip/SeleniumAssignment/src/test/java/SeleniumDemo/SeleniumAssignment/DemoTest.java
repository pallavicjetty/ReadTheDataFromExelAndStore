package SeleniumDemo.SeleniumAssignment;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import SeleniumDemo.SeleniumAssignment.PageObjects.HomePage;
import utilities.ExcelUtilis;

public class DemoTest extends BaseClass{
	
	@Test
	public void TestMethod()
	{
		HomePage homePage= new HomePage(driver);
		ExcelUtilis excelUtilis = new ExcelUtilis();
		homePage.ClickFromField("DEL");
		homePage.SelectValueFromDropdown();
		excelUtilis.getRowCount();
		homePage.SelectSortOnDateFrom30Day();
	}
}
