package SeleniumDemo.SeleniumAssignment;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class BaseClass {
	public WebDriver driver;
	
	@BeforeClass
	public void TestInitialize()
	{	
		driver= new ChromeDriver();
		// Maximize the browser
        driver.manage().window().maximize();
 
        // Launch Website
        driver.get("https://erail.in/");

	}
}
